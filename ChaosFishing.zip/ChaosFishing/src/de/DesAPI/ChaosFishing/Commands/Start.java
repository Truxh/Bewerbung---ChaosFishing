package de.DesAPI.ChaosFishing.Commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import de.DesAPI.ChaosFishing.Main.Main;

public class Start
  implements CommandExecutor
{
  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
  {
    if ((cmd.getName().equalsIgnoreCase("start")) && 
      (args.length == 0) && 
      (sender.hasPermission("labs.start"))) {
      if (Main.main.cd.lobby > 5)
      {
        Main.main.cd.lobby = 5;
        sender.sendMessage(Main.pr + "§aDu hast das Spiel vorzeitig gestartet!");
      }
      else
      {
        sender.sendMessage("§aDas Spiel läuft bereits!");
      }
    }
    return false;
  }
}
