package de.DesAPI.ChaosFishing.Commands;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class Shop
  implements CommandExecutor
{
  public boolean onCommand(CommandSender sender, Command cmd, String alias, String[] args)
  {
    Player p = (Player)sender;
    if (cmd.getName().equalsIgnoreCase("shop"))
    {
      Inventory i = Bukkit.createInventory(null, 9, "Shop");
      
      for (int in = 0; in < 9; in++)
      {
        ItemStack i1 = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)7);
        ItemMeta i1m = i1.getItemMeta();
        i1m.setDisplayName("§0");
        i1.setItemMeta(i1m);
        
        i.setItem(in, i1);
      }
      
      ItemStack stack = new ItemStack(Material.MONSTER_EGG, 5, EntityType.CREEPER.getTypeId());
      ItemMeta meta = stack.getItemMeta();
      meta.setDisplayName("§a5 Creeperpfeile");
      List<String> lore = new ArrayList();
      lore.add("§7Preis: §a1 §7Level");
      meta.setLore(lore);
      stack.setItemMeta(meta);
      
      
      ItemStack stack111 = new ItemStack(Material.GOLDEN_APPLE, 3);
      ItemMeta meta111 = stack111.getItemMeta();
      meta111.setDisplayName("§63 Goldäpfel");
      List<String> lore111 = new ArrayList();
      lore111.add("§7Preis: §a1 §7Level");
      meta111.setLore(lore111);
      stack111.setItemMeta(meta111);
     
      
      ItemStack stack21 = new ItemStack(Material.POTION, 1, (short)8258);
      ItemMeta meta21 = stack21.getItemMeta();
      meta21.setDisplayName("§b1 Speedeffekt");
      List<String> lore21 = new ArrayList();
      lore21.add("§7Preis: §a3 §7Level");
      meta21.setLore(lore21);
      stack21.setItemMeta(meta21);
      
      ItemStack stack211 = new ItemStack(Material.POTION, 1, (short)8259);
      ItemMeta meta211 = stack211.getItemMeta();
      meta211.setDisplayName("§c1 Feuerressistenztrank");
      List<String> lore211 = new ArrayList();
      lore211.add("§7Preis: §a3 §7Level");
      meta211.setLore(lore211);
      stack211.setItemMeta(meta211);
      
      
   
      
      i.setItem(0, stack);
      i.setItem(1, stack111);
      i.setItem(7, stack21);
      i.setItem(8, stack211);

      p.openInventory(i);
    }
    return false;
  }
}
