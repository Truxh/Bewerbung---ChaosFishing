package de.DesAPI.ChaosFishing.Listener;

import java.util.ArrayList;
import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;

import de.DesAPI.ChaosFishing.Main.Main;

public class DeathListener
  implements Listener
{
  @EventHandler
  public void onDeath(PlayerDeathEvent e)
  {
    Player p = e.getEntity();
    if (Main.main.alive.contains(p))
    {
      Main.main.alive.remove(p);
      if (Main.main.lastdmg.containsKey(p))
      {
        e.setDeathMessage(Main.pr + ChatColor.GREEN  + p.getDisplayName() + " §6wurde von " + ((Player)Main.main.lastdmg.get(p)).getDisplayName() + " §cgetötet!");
        
        Main.main.Win();
      }
      else
      {
        e.setDeathMessage(Main.pr + ChatColor.GREEN + p.getDisplayName() + " §cist gestorben!");
        
        Main.main.Win();
      }
      for (Player all : Bukkit.getOnlinePlayers()) {
        all.hidePlayer(p);
        
      }
    }
    else
    {
      e.setDeathMessage(null);
      Main.main.Win();
    }
  }
  
  @EventHandler
  public void onRespawn(PlayerRespawnEvent e)
  {
    Player p = e.getPlayer();
    ItemStack compass = new ItemStack(Material.COMPASS, 1);
    ItemMeta compassmeta = compass.getItemMeta();
    compassmeta.setDisplayName("§aTeleporter");
    compass.setItemMeta(compassmeta);
    p.getInventory().addItem(new ItemStack[] { compass });
    p.setAllowFlight(true);
    p.setFlying(true);
  }
}
