package de.DesAPI.ChaosFishing.Listener;

import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;

import de.DesAPI.ChaosFishing.Main.Main;

public class ShopClickEvent
  implements Listener
{
  @EventHandler
  public void onClick(InventoryClickEvent e)
  {
    Player p = (Player)e.getWhoClicked();
    int amount = p.getLevel();
    if (e.getCurrentItem() == null) {
      return;
    }
    if (e.getCurrentItem().getType() == Material.AIR) {
      return;
    }
    if (e.getClickedInventory().getName().equals("Shop"))
    {
      e.setCancelled(true);
      //CreeperPfeile
      if (e.getCurrentItem().getItemMeta().getDisplayName().equals("§a5 Creeperpfeile"))
      {
        if (amount > 0)
        {
          e.getView().close();
          amount--;
          p.setLevel(amount);
          ItemStack stack = new ItemStack(Material.MONSTER_EGG, 5, EntityType.CREEPER.getTypeId());
          p.getInventory().addItem(new ItemStack[] { stack });
          p.updateInventory();
          p.sendMessage(Main.pr + "§7Dein Kauf war erfolgreich!");
        }
        else
        {
          e.getView().close();
          p.sendMessage(Main.pr + "§cDu hast nicht genug Level!");
        }
      }
      
      //Gapples
      else if (e.getCurrentItem().getItemMeta().getDisplayName().equals("§63 Goldäpfel"))
      {
        if (amount > 0)
        {
          e.getView().close();
          amount--;
          p.setLevel(amount);
          ItemStack stack = new ItemStack(Material.GOLDEN_APPLE, 3);
          ItemMeta meta = stack.getItemMeta();
          meta.setDisplayName("§6Goldapfel");
          stack.setItemMeta(meta);
          p.getInventory().addItem(new ItemStack[] { stack });
          p.updateInventory();
          p.sendMessage(Main.pr + "§7Dein Kauf war erfolgreich!");
        }
        else
        {
          e.getView().close();
          p.sendMessage(Main.pr + "§cDu hast nicht genug Level!");
        }
      }
      
      //Trank 1
      else if (e.getCurrentItem().getItemMeta().getDisplayName().equals("§b1 Speedeffekt"))
      {
        if (amount > 2)
        {
          e.getView().close();
          amount--;
          p.setLevel(amount);
          ItemStack stack = new ItemStack(Material.POTION, 1, (short)8258);
          
          p.getInventory().addItem(new ItemStack[] { stack });
          p.updateInventory();
          p.sendMessage(Main.pr + "§7Dein Kauf war erfolgreich!");
        }
        else
        {
          e.getView().close();
          p.sendMessage(Main.pr + "§cDu hast nicht genug Level!");
        }
      }
  
      
      //Trank 2
      else if (e.getCurrentItem().getItemMeta().getDisplayName().equals("§c1 Feuerressistenztrank")) {
        if (amount > 2)
        {
          e.getView().close();
          amount--;
          p.setLevel(amount);
          ItemStack stack = new ItemStack(Material.POTION, 1, (short)8259);
          p.getInventory().addItem(new ItemStack[] { stack });
          p.updateInventory();
          p.sendMessage(Main.pr + "§7Dein Kauf war erfolgreich!");
        }
        else
        {
          e.getView().close();
          p.sendMessage(Main.pr + "§cDu hast nicht genug Level!");
        }
      }
    }
  }
}
