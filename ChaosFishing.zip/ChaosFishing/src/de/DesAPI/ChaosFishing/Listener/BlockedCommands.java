package de.DesAPI.ChaosFishing.Listener;

import de.DesAPI.ChaosFishing.CountDown.Gamestate;
import de.DesAPI.ChaosFishing.Main.Main;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public class BlockedCommands
  implements Listener {
  
  public void BlockedCommand(PlayerCommandPreprocessEvent e) {
  
    		  if (Main.main.state == Gamestate.Lobby || !Main.main.alive.contains(e.getPlayer()))
    		   {
    			  if(e.getMessage().equalsIgnoreCase("/start")) {
    				  e.setCancelled(true);
    			  }
    		   }
    		  else if (Main.main.state != Gamestate.Ingame) 
    		  {
    			  if(e.getMessage().equalsIgnoreCase("/start")) {
    			  {
    				  e.setCancelled(false);
    			  }
    		  }	
    		  }
  }
}
      