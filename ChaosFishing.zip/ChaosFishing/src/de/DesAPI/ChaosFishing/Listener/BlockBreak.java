package de.DesAPI.ChaosFishing.Listener;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import de.DesAPI.ChaosFishing.CountDown.Gamestate;
import de.DesAPI.ChaosFishing.Main.Main;

public class BlockBreak
  implements Listener
{

  @EventHandler
  public void breakBlock(BlockBreakEvent e)
  {
    Block b = e.getBlock();
    if (Main.main.state == Gamestate.Ingame)
    {
      if (b.getType() == Material.LONG_GRASS)
      {
        e.setCancelled(true);
        b.setType(Material.AIR);
        b.getWorld().dropItemNaturally(b.getLocation(), new ItemStack(Material.BREAD));
      }
      else if (b.getType() == Material.COAL_ORE)
      {
        e.setCancelled(true);
        b.setType(Material.AIR);
        b.getWorld().dropItemNaturally(b.getLocation(), new ItemStack(Material.TORCH, 2));
      }
      else if (b.getType() == Material.IRON_ORE)
      {
        e.setCancelled(true);
        b.setType(Material.AIR);
        b.getWorld().dropItemNaturally(b.getLocation(), new ItemStack(Material.IRON_INGOT, 2));
      }
      else if (b.getType() == Material.GOLD_ORE)
      {
        e.setCancelled(true);
        b.setType(Material.AIR);
        b.getWorld().dropItemNaturally(b.getLocation(), new ItemStack(Material.GOLD_INGOT, 2));
      }
      else if (b.getType() == Material.DIAMOND_ORE)
      {
        e.setCancelled(true);
        b.setType(Material.AIR);
        b.getWorld().dropItemNaturally(b.getLocation(), new ItemStack(Material.DIAMOND, 2));
      }
      else if (b.getType() == Material.SAND)
      {
        e.setCancelled(true);
        b.setType(Material.AIR);
        b.getWorld().dropItemNaturally(b.getLocation(), new ItemStack(Material.GLASS, 3));
      }
      else if (b.getType() == Material.GRAVEL)
      {
        e.setCancelled(true);
        b.setType(Material.AIR);
        b.getWorld().dropItemNaturally(b.getLocation(), new ItemStack(Material.ARROW, 2));
      }
      else if ((b.getType() == Material.LOG) || (b.getType() == Material.LOG_2))
      {
        Block b1 = e.getBlock().getLocation().add(0.0D, 2.0D, 0.0D).getBlock();
        while ((b1.getType() == Material.LOG) || (b.getType() == Material.LOG_2))
        {
          Block b2 = b1.getLocation().add(0.0D, -1.0D, 0.0D).getBlock();
          while ((b2.getType() == Material.LOG) || (b.getType() == Material.LOG_2)) {
            b2.breakNaturally();
          }
          Block b3 = b1.getLocation().add(0.0D, -3.0D, 0.0D).getBlock();
          while ((b3.getType() == Material.LOG) || (b.getType() == Material.LOG_2)) {
            b3.breakNaturally();
          }
          b1.breakNaturally();
          b1 = b1.getLocation().add(0.0D, 1.0D, 0.0D).getBlock();
        }
      }
      else if ((b.getType() == Material.LEAVES) || (b.getType() == Material.LEAVES_2))
      {
        double rnd = Math.random() * 100.0D;
        if (rnd <= 2.5D) {
          b.getWorld().dropItemNaturally(b.getLocation(), new ItemStack(Material.GOLDEN_APPLE));
        }
        if (rnd >= 80.0D) {
          b.getWorld().dropItemNaturally(b.getLocation(), new ItemStack(Material.APPLE));
        }
      }
    }
    else {
      e.setCancelled(true);
    }

  }
}
