package de.DesAPI.ChaosFishing.Listener;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import org.bukkit.Bukkit;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerFishEvent.State;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerLoginEvent.Result;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.server.ServerListPingEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;

import com.avaje.ebeaninternal.server.deploy.BeanDescriptor.EntityType;

import de.DesAPI.ChaosFishing.CountDown.Countdown;
import de.DesAPI.ChaosFishing.CountDown.Gamestate;
import de.DesAPI.ChaosFishing.Main.Main;
import net.md_5.bungee.api.ChatColor;

public class Events
  implements Listener
{
	//Join Event
  @EventHandler
  public void onJoin(PlayerJoinEvent e)
  {
	  for (Player p : Bukkit.getOnlinePlayers()) {
    Main.main.utils.clearPlayer(p);  
        org.bukkit.scoreboard.Scoreboard board2 = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective ob = board2.registerNewObjective("dummy", "test");
        ob.setDisplaySlot(DisplaySlot.SIDEBAR);
        ob.setDisplayName("§6>> §l§eChaosFishing");
        ob.getScore("§l§eServer-IP:").setScore(3);
        ob.getScore("§fberkwerkLABS.de").setScore(2);
        ob.getScore("").setScore(1);
        ob.getScore("").setScore(0);
        p.getScoreboard().clearSlot(DisplaySlot.SIDEBAR);
        p.setScoreboard(board2);
    if (Main.main.state == Gamestate.Lobby)
    {
      if (!Main.main.alive.contains(p)) {
        Main.main.alive.add(p);
      }
      e.setJoinMessage(Main.pr + ChatColor.GOLD + p.getDisplayName() + " §7ist dem Spiel beigetreten.");
      p.teleport(Main.main.lm.getLocation("lobby"));
      Main.main.utils.clearPlayer(p);
      if (Bukkit.getOnlinePlayers().size() == Main.main.min) {
        Main.main.cd.startLobbyCD();
      }
      if (Main.main.lm.getLocation("lobby") == null) {
        p.sendMessage(Main.pr + "§cDie Lobby wurde noch nicht gesetzt!");
      }
    }
    else
    {
      p.kickPlayer(Main.pr + "Das Spiel hat schon begonnen!");
      {
      }
      
  }
    }
	  }
  
 

//Login
  @EventHandler
  public void onLogin(PlayerLoginEvent e)
  {
    if (Main.main.state != Gamestate.Lobby)
    {
      e.disallow(PlayerLoginEvent.Result.KICK_FULL, Main.pr + "§cDas Spiel hat schon begonnen!");
      return;
    }
    if (Main.main.alive.size() >= Main.main.max) {
      e.disallow(PlayerLoginEvent.Result.KICK_OTHER, Main.pr + "§cDas Spiel ist voll!");
    }
  }
  
  //Leave Event
  @EventHandler
  public void onLeave(PlayerQuitEvent e)
  {
    Player p = e.getPlayer();
    if ((Main.main.state == Gamestate.Lobby) && 
      (Main.main.alive.contains(p))) {
      Main.main.alive.remove(p);
    }
    if ((Main.main.state == Gamestate.Ingame) || (Main.main.state == Gamestate.Friede))
    {
      if (Main.main.alive.contains(p))
      {
        Main.main.alive.remove(p);
        p.setHealth(0.0D);
        e.setQuitMessage(Main.pr + "§c" + p.getDisplayName() + " §7ist gestorben");
      }
      else
      {
        e.setQuitMessage(null);
      }
    }
    else {
      e.setQuitMessage("§" + p.getDisplayName() + " §7hat das Spiel verlassen");
    }
  }
  
  
  
  @EventHandler
  public void onLoseFeed(FoodLevelChangeEvent e)
  {
    if ((Main.main.state == Gamestate.Ingame) || (Main.main.state == Gamestate.DeathMatch)) {
      e.setCancelled(false);
    } else {
      e.setCancelled(true);
    }
  }
  
  
  @EventHandler
  public void onDamage(EntityDamageEvent e)
  {
    if ((Main.main.state == Gamestate.Lobby) || (Main.main.state == Gamestate.Friede) || 
      (Main.main.state == Gamestate.Restarting))
    {
      e.setCancelled(true);
      if (e.getCause() == EntityDamageEvent.DamageCause.FALL) {
        e.setCancelled(true);
      }
    }
    else
    {
      e.setCancelled(false);
    }
  }
  
  
  @EventHandler
  public void onEntDmgByEnt(EntityDamageByEntityEvent e)
  {
    if ((Main.main.state == Gamestate.Ingame) || (Main.main.state == Gamestate.DeathMatch)) {
      e.setCancelled(false);
    } else {
      e.setCancelled(true);
    }
  }

  //Break Event
  @EventHandler
  public void onBreak(BlockBreakEvent e)
  {
	  if (Main.main.state == Gamestate.Lobby)
	    {
    e.setCancelled(true);
  }
  
	  else if (Main.main.state != Gamestate.Ingame) {
	    e.setCancelled(false);
  }
	  else if (Main.main.state != Gamestate.DeathMatch) {
		    e.setCancelled(false);
	  }
 
  }

  //PlaceEvent
  @EventHandler
  public void onPlace(BlockPlaceEvent e) {
	  
  if (Main.main.state == Gamestate.Lobby)
  {
e.setCancelled(true);
}

else if (Main.main.state != Gamestate.Ingame) {
  e.setCancelled(false);
}
else if (Main.main.state != Gamestate.DeathMatch) {
    e.setCancelled(false);
}
}
  //Drop Event
  @EventHandler
  public void onDrop(PlayerDropItemEvent e)
  {
    if (!Main.main.alive.contains(e.getPlayer()))
    {
      e.setCancelled(true);
      return;
    }
    if (Main.main.state != Gamestate.Ingame) {
      e.setCancelled(false);
    }
	  else if (Main.main.state != Gamestate.DeathMatch) {
		    e.setCancelled(false);
  }
  }
  //Pickup Event
  @EventHandler
  public void onPickup(PlayerPickupItemEvent e)
  {
	  if (Main.main.state == Gamestate.Lobby || !Main.main.alive.contains(e.getPlayer()))
	    {
  e.setCancelled(true);
}

	  else if (Main.main.state != Gamestate.Ingame) {
	    e.setCancelled(false);
}
	  else if (Main.main.state != Gamestate.DeathMatch) {
		    e.setCancelled(false);
	  }

}

  //Chest Loot | Fishing
  @EventHandler
  public void onPlayerFish(PlayerFishEvent e)
  {
    if (e.getState() == PlayerFishEvent.State.CAUGHT_FISH)
    {
      Player p = e.getPlayer();
      Inventory inv = Bukkit.createInventory(null, InventoryType.CHEST);
      Random rnd = new Random();
      int n = 1;
      n = rnd.nextInt(6);
      List<ItemStack> items = new ArrayList();
      items.add(new ItemStack(Material.POTATO_ITEM, 2));
      items.add(new ItemStack(Material.POTATO_ITEM, 4));
      items.add(new ItemStack(Material.MELON));
      items.add(new ItemStack(Material.PUMPKIN_PIE));
      items.add(new ItemStack(Material.BREAD));
      items.add(new ItemStack(Material.BONE));
      items.add(new ItemStack(Material.BONE, 2));
      items.add(new ItemStack(Material.CARROT_ITEM));
      items.add(new ItemStack(Material.CARROT_ITEM, 2));
      items.add(new ItemStack(Material.CARROT_ITEM, 4));
      
      
      
      items.add(new ItemStack(Material.CAKE));
      items.add(new ItemStack(Material.IRON_INGOT));
      items.add(new ItemStack(Material.IRON_INGOT, 2));
      items.add(new ItemStack(Material.IRON_LEGGINGS));
      items.add(new ItemStack(Material.IRON_BOOTS));
      items.add(new ItemStack(Material.IRON_HELMET));
      items.add(new ItemStack(Material.BOW));
      items.add(new ItemStack(Material.ARROW));
      items.add(new ItemStack(Material.ARROW, 5));
      items.add(new ItemStack(Material.ARROW, 11));
      
      
      
      
      
      items.add(new ItemStack(Material.COOKED_BEEF));
      items.add(new ItemStack(Material.COOKED_BEEF, 2));
      items.add(new ItemStack(Material.BAKED_POTATO));
      items.add(new ItemStack(Material.BAKED_POTATO, 2));
      items.add(new ItemStack(Material.POTATO_ITEM));
      items.add(new ItemStack(Material.BONE, 4));
      items.add(new ItemStack(Material.LEATHER));
      items.add(new ItemStack(Material.APPLE));
      items.add(new ItemStack(Material.APPLE, 2));
      items.add(new ItemStack(Material.APPLE, 4));
      items.add(new ItemStack(Material.GOLD_INGOT));
      items.add(new ItemStack(Material.GOLD_INGOT, 2));
      
      
      
      
      
      items.add(new ItemStack(Material.STICK));
      items.add(new ItemStack(Material.STICK, 2));
      items.add(new ItemStack(Material.STICK, 4));
      items.add(new ItemStack(Material.STONE_SWORD));
      items.add(new ItemStack(Material.WOOD_SWORD));
      items.add(new ItemStack(Material.GOLD_SWORD));
      items.add(new ItemStack(Material.STONE_SWORD));
      items.add(new ItemStack(Material.WOOD_SWORD));
      items.add(new ItemStack(Material.WOOD_SPADE));
      items.add(new ItemStack(Material.ENDER_PEARL));
      items.add(new ItemStack(Material.ENDER_PEARL, 2));
      items.add(new ItemStack(Material.ENDER_PEARL, 3));
      items.add(new ItemStack(Material.STONE_SWORD));
      items.add(new ItemStack(Material.WOOD_SWORD));
      
      
      
      
      items.add(new ItemStack(Material.GOLD_SWORD));
      items.add(new ItemStack(Material.STONE_SWORD));
      items.add(new ItemStack(Material.WOOD_SWORD));
      items.add(new ItemStack(Material.FLINT));
      items.add(new ItemStack(Material.FLINT_AND_STEEL));
      items.add(new ItemStack(Material.BOWL));
      items.add(new ItemStack(Material.RED_MUSHROOM));
      items.add(new ItemStack(Material.BROWN_MUSHROOM));
      items.add(new ItemStack(Material.COOKED_CHICKEN));
      items.add(new ItemStack(Material.RAW_BEEF));
      items.add(new ItemStack(Material.RAW_CHICKEN));
      items.add(new ItemStack(Material.RAW_FISH));
      items.add(new ItemStack(Material.COOKED_FISH));
      items.add(new ItemStack(Material.COOKED_CHICKEN, 2));
      
      
      
      items.add(new ItemStack(Material.RAW_BEEF, 2));
      items.add(new ItemStack(Material.RAW_CHICKEN, 2));
      items.add(new ItemStack(Material.RAW_FISH, 2));
      items.add(new ItemStack(Material.COOKED_FISH, 2));
      items.add(new ItemStack(Material.COOKED_CHICKEN, 4));
      items.add(new ItemStack(Material.RAW_BEEF, 4));
      items.add(new ItemStack(Material.RAW_CHICKEN, 4));
      items.add(new ItemStack(Material.RAW_FISH, 4));
      items.add(new ItemStack(Material.COOKED_FISH, 4));
      
      
      
      items.add(new ItemStack(Material.COOKIE));
      items.add(new ItemStack(Material.COOKIE, 2));
      items.add(new ItemStack(Material.COOKIE, 4));
      items.add(new ItemStack(Material.LEATHER_CHESTPLATE));
      items.add(new ItemStack(Material.WOOD_AXE));
      items.add(new ItemStack(Material.LEATHER_LEGGINGS));
      items.add(new ItemStack(Material.LEATHER_BOOTS));
      items.add(new ItemStack(Material.CHAINMAIL_HELMET));
      items.add(new ItemStack(Material.LEATHER_HELMET));
      
      
      items.add(new ItemStack(Material.STONE_AXE));
      items.add(new ItemStack(Material.EGG));
      items.add(new ItemStack(Material.EGG, 3));
      items.add(new ItemStack(Material.EXP_BOTTLE));
      items.add(new ItemStack(Material.CHAINMAIL_BOOTS));
      items.add(new ItemStack(Material.CHAINMAIL_CHESTPLATE));
      items.add(new ItemStack(Material.CHAINMAIL_LEGGINGS));
      
      
      items.add(new ItemStack(Material.WEB));
      items.add(new ItemStack(Material.WEB, 3));
      items.add(new ItemStack(Material.STRING));
      items.add(new ItemStack(Material.STRING, 2));
      items.add(new ItemStack(Material.STRING, 4));
      items.add(new ItemStack(Material.FEATHER));
      items.add(new ItemStack(Material.FEATHER, 4));
      while (n != 0)
      {
        n--;
        Random rnd2 = new Random();
        Random rnd3 = new Random();
        int n3 = rnd.nextInt(27);
        int n2 = rnd2.nextInt(items.size());
        
        inv.setItem(n3, (ItemStack)items.get(n2));
        e.setCancelled(true);
        p.openInventory(inv);
      }
    }
  }
  //MOTD - Ping
  @EventHandler
  public void onPing(ServerListPingEvent e)
  {
    e.setMaxPlayers(Main.main.max);
    if (Main.main.state == Gamestate.Lobby) {
      e.setMotd("§aLobby - ChaosFishing");
    } else if (Main.main.state == Gamestate.Ingame) {
      e.setMotd("§aIngame");
    } else if (Main.main.state == Gamestate.Restarting) {
      e.setMotd("§aRestarting");
    }
  }
  //Damage Event


  //TNT Event
  @EventHandler(priority=EventPriority.HIGH)
  public void tntPlace(BlockPlaceEvent event)
  {
    if (event.getBlock().getType() == Material.TNT)
    {
      event.getBlock().setType(Material.AIR);
      Entity tnt = event.getPlayer().getWorld().spawn(event.getBlock().getLocation(), TNTPrimed.class);
      ((TNTPrimed)tnt).setFuseTicks(20);
    }
  }
  
//Explosion
  @EventHandler
  public void onEntityExplode(EntityExplodeEvent event) {
     event.blockList().clear();
  }

  

  
  //Chat Event AsyncPlayerChat
  @EventHandler
  public void onChat(AsyncPlayerChatEvent e)
  {
    Player p = e.getPlayer();
    if (Main.main.alive.contains(p)) {
      Bukkit.broadcastMessage("§7" + p.getDisplayName() + "§8: §7" + e.getMessage());
    } else {
      for (Player all : Bukkit.getOnlinePlayers()) {
        if (!Main.main.alive.contains(all)) {
          all.sendMessage("§7" + p.getDisplayName() + "§8: §7" + e.getMessage());
        }
      }
    }
    e.setCancelled(true);
  }
}
