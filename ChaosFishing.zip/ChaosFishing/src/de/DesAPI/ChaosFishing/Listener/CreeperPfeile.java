package de.DesAPI.ChaosFishing.Listener;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Egg;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

public class CreeperPfeile
  implements Listener
{
  @EventHandler(priority=EventPriority.NORMAL)
  public void onProjectileHit(EntityShootBowEvent event)
  {
    if ((event.getEntity() instanceof Player))
    {
      Player player = (Player)event.getEntity();
      int slot = player.getInventory().first(Material.MONSTER_EGG);
      if (slot >= 0)
      {
        ItemStack item = player.getInventory().getItem(slot);
        if (item.getAmount() > 1) {
          item.setAmount(item.getAmount() - 1);
        } else {
          player.getInventory().setItem(slot, null);
        }
      }
    }
  }
  
  @EventHandler(priority=EventPriority.NORMAL)
  public void onProjectileHit(ProjectileHitEvent event)
  {
    Entity entity = event.getEntity();
    LivingEntity projectile = (LivingEntity)event.getEntity().getShooter();
    if ((projectile instanceof Player))
    {
      Player player = (Player)projectile;
      if (((entity instanceof Arrow)) && 
        (player.getInventory().contains(Material.MONSTER_EGG)))
      {
        Arrow arrow = (Arrow)entity;
        
        Creeper localCreeper = (Creeper)event.getEntity().getWorld().spawnEntity(arrow.getLocation(), EntityType.CREEPER);
      }
      if ((entity instanceof Egg))
      {
        Egg egg = (Egg)entity;
        Location loc = egg.getLocation();
        loc.getWorld().createExplosion(loc.getX(), loc.getY(), loc.getZ(), 2.0F, false, false);
        loc.getWorld().playSound(loc, Sound.EXPLODE, -4.0F, 12.0F);
      }
    }
  }
  
  @EventHandler
  public void ExplodeEvent(EntityExplodeEvent event)
  {
    if (event.getEntityType() == EntityType.CREEPER) {
      event.setCancelled(true);
    }
  }
}
