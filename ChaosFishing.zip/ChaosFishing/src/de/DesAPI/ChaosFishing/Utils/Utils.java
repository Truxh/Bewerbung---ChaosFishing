package de.DesAPI.ChaosFishing.Utils;

import java.util.ArrayList;
import java.util.Random;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;

import de.DesAPI.ChaosFishing.Main.Main;

public class Utils
{
  public ArrayList<ItemStack> loot;
  
  public ItemStack create(Material mat, int amount)
  {
    return new ItemStack(mat, amount);
  }
  
  public ItemStack createCustom(Material mat, int amount, short id, String display)
  {
    ItemStack it = new ItemStack(mat, amount, id);
    ItemMeta meta = it.getItemMeta();
    meta.setDisplayName(display);
    it.setItemMeta(meta);
    return it;
  }
  
  public void clearPlayer(Player p)
  {
    p.setHealth(20.0D);
    p.setFoodLevel(20);
    p.setLevel(0);
    p.setExp(0.0F);
    p.getInventory().clear();
    p.getInventory().setArmorContents(null);
    for (PotionEffect effect : p.getActivePotionEffects()) {
      p.removePotionEffect(effect.getType());
    }
  }
  
  public int rndInt(int min, int max)
  {
    Random r = new Random();
    int i = r.nextInt(max - min + 1) + min;
    return i;
  }
  
  public void registerLoot()
  {
    this.loot.add(Main.main.utils.create(Material.WOOD_SWORD, 1));
    this.loot.add(Main.main.utils.create(Material.WOOD_AXE, 1));
    this.loot.add(Main.main.utils.create(Material.IRON_SWORD, 1));
    this.loot.add(Main.main.utils.create(Material.IRON_AXE, 1));
    this.loot.add(Main.main.utils.create(Material.GOLD_SWORD, 1));
    this.loot.add(Main.main.utils.create(Material.GOLD_AXE, 1));
    this.loot.add(Main.main.utils.create(Material.DIAMOND_AXE, 1));
    this.loot.add(Main.main.utils.create(Material.DIAMOND_SWORD, 1));
    this.loot.add(Main.main.utils.create(Material.BOW, 1));
    this.loot.add(Main.main.utils.create(Material.ARROW, 1));
    this.loot.add(Main.main.utils.create(Material.FISHING_ROD, 1));
    
    this.loot.add(Main.main.utils.create(Material.COOKED_FISH, 1));
    this.loot.add(Main.main.utils.create(Material.BRICK, 1));
    this.loot.add(Main.main.utils.create(Material.BED, 1));
    this.loot.add(Main.main.utils.create(Material.WOOD_HOE, 1));
    this.loot.add(Main.main.utils.create(Material.WOOD_PLATE, 1));
    this.loot.add(Main.main.utils.create(Material.ACACIA_DOOR, 1));
    
    this.loot.add(Main.main.utils.create(Material.LEATHER_HELMET, 1));
    this.loot.add(Main.main.utils.create(Material.LEATHER_CHESTPLATE, 1));
    this.loot.add(Main.main.utils.create(Material.LEATHER_LEGGINGS, 1));
    this.loot.add(Main.main.utils.create(Material.LEATHER_BOOTS, 1));
    
    this.loot.add(Main.main.utils.create(Material.GOLD_HELMET, 1));
    this.loot.add(Main.main.utils.create(Material.GOLD_CHESTPLATE, 1));
    this.loot.add(Main.main.utils.create(Material.GOLD_LEGGINGS, 1));
    this.loot.add(Main.main.utils.create(Material.GOLD_BOOTS, 1));
    
    this.loot.add(Main.main.utils.create(Material.IRON_HELMET, 1));
    this.loot.add(Main.main.utils.create(Material.IRON_CHESTPLATE, 1));
    this.loot.add(Main.main.utils.create(Material.IRON_LEGGINGS, 1));
    this.loot.add(Main.main.utils.create(Material.IRON_BOOTS, 1));
    
    this.loot.add(Main.main.utils.create(Material.DIAMOND_HELMET, 1));
    this.loot.add(Main.main.utils.create(Material.DIAMOND_CHESTPLATE, 1));
    this.loot.add(Main.main.utils.create(Material.DIAMOND_LEGGINGS, 1));
    this.loot.add(Main.main.utils.create(Material.DIAMOND_BOOTS, 1));
  }
}
