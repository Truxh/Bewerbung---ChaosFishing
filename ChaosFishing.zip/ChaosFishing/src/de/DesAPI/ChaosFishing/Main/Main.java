package de.DesAPI.ChaosFishing.Main;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;


import de.DesAPI.ChaosFishing.Methods.TitlesAPI;
import de.DesAPI.ChaosFishing.CountDown.Countdown;
import de.DesAPI.ChaosFishing.CountDown.Gamestate;
import de.DesAPI.ChaosFishing.Files.FileManager;
import de.DesAPI.ChaosFishing.Files.LocationManager;
import de.DesAPI.ChaosFishing.Listener.BlockBreak;
import de.DesAPI.ChaosFishing.Listener.BlockedCommands;
import de.DesAPI.ChaosFishing.Listener.CreeperPfeile;
import de.DesAPI.ChaosFishing.Listener.DeathListener;
import de.DesAPI.ChaosFishing.Listener.Events;
import de.DesAPI.ChaosFishing.Listener.ShopClickEvent;
import de.DesAPI.ChaosFishing.Listener.Teleporter;
import de.DesAPI.ChaosFishing.Utils.Utils;
import net.minecraft.server.v1_8_R3.Block;
import net.minecraft.server.v1_8_R3.Material;
import de.DesAPI.ChaosFishing.Commands.Shop;
import de.DesAPI.ChaosFishing.Commands.Start;
import de.DesAPI.ChaosFishing.Commands.setLobby;
import de.DesAPI.ChaosFishing.Commands.setSpawn;
import de.DesAPI.ChaosFishing.Commands.setDeathMatch
;
public class Main
  extends JavaPlugin
{
  public static Main main;
  public Gamestate state;
  public ArrayList<Player> alive;
  public ArrayList<Player> schutz;
  public static String pr = "§6>> §eChaosFishing §6| ";
  public HashMap<String, BukkitTask> countdown = new HashMap();
  public HashMap<String, BukkitTask> tasks = new HashMap();
  public Utils utils;
  public ArrayList<String> schutz_zeit_join = new ArrayList();
  public int min = 2;
  public int max = 6;
  public int sz = 180;
  public int deathmatch = 300;
  public int bevor = 60;
  public boolean newgame = false;
  public HashMap<Player, Player> lastdmg = new HashMap();
  public int lobby = 20;
  public FileManager fm;
  public LocationManager lm;
  public Countdown cd;
  
  public int ingame = 1800;
  public int restart = 15;
  public int frieden = 3;
  public int dmstart = 4;

  
  
  public void onEnable()
  {
    main = this;
    this.lm = new LocationManager();
    this.lastdmg = new HashMap<Player, Player>();
    this.state = Gamestate.Lobby;
    this.alive = new ArrayList<Player>();
    this.schutz = new ArrayList<Player>();
    this.fm = new FileManager();

    this.cd = new Countdown();
    this.utils = new Utils();
    this.fm.saveCfg();
    this.fm.register();
    this.lm.saveCfg();
    
    Bukkit.getPluginManager().registerEvents(new Events(), this);
    Bukkit.getPluginManager().registerEvents(new DeathListener(), this);
    Bukkit.getPluginManager().registerEvents(new BlockedCommands(), this);
    Bukkit.getPluginManager().registerEvents(new Teleporter(), this);
    getServer().getPluginManager().registerEvents(new ShopClickEvent(), this);
    getServer().getPluginManager().registerEvents(new CreeperPfeile(), this);
    getServer().getPluginManager().registerEvents(new BlockBreak(), this);
    getCommand("setLobby").setExecutor(new setLobby());
    getCommand("start").setExecutor(new Start());
    getCommand("setSpawn").setExecutor(new setSpawn());
    getCommand("Shop").setExecutor(new Shop());
    getCommand("setdeathmatch").setExecutor(new setDeathMatch());
  
  }
 
  public void onDisable() {
  }
@SuppressWarnings("deprecation")
public void Win()
  {
    if ((this.state == Gamestate.Ingame) || (this.state == Gamestate.DeathMatch)) {
      if (Bukkit.getOnlinePlayers().size() == 0)
      {
    	  Countdown.startRestartCD();
      }
    	 else if (this.alive.size() == 1)
        {
          Player winner = (Player)this.alive.get(0);
          for (Player all : Bukkit.getOnlinePlayers())
          {
            main.utils.clearPlayer(all);
            all.sendTitle(winner.getDisplayName(), "§ehat gewonnen§7!");
            all.sendMessage(Main.pr + "§a" + winner.getDisplayName() + " §ehat das Spiel gewonnen!");
          }
          Countdown.startRestartCD();
      }
    }
  }
}

