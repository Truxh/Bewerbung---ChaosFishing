package de.DesAPI.ChaosFishing.CountDown;

import java.util.Iterator;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import de.DesAPI.ChaosFishing.Main.Main;

public class Countdown
{
  
  public static boolean lobbystarted = false;
  public static boolean restartstarted = false;
  public static int lobbycd;
  public static int friedencd;
  public static int ingamecd;
  
  public static int deathmatchcd;
  public static int bevorcd;
  public static int restartcd;
  public static int lobby = Main.main.lobby;
  static int frieden = Main.main.frieden;
  static int ingame = Main.main.ingame;
  static int bevor = Main.main.bevor;
  static int deathmatch = Main.main.deathmatch;
  static int restart = Main.main.restart;
  
  public static void startLobbyCD()
  {
    Main.main.state = Gamestate.Lobby;
    if (!lobbystarted)
    {
      lobbystarted = true;
      lobbycd = Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.main, new Runnable()
      {
        public void run()
        {
          if (Countdown.lobby >= 1)
          {
            if (((Bukkit.getOnlinePlayers().size() == Main.main.max - 1) || 
              (Bukkit.getOnlinePlayers().size() == Main.main.max - 2)) && 
              (Countdown.lobby <= 5) && (Countdown.lobby >= 1))
            {
              Countdown.lobby = 30;
              for (Player all : Bukkit.getOnlinePlayers())
              {
                all.playSound(all.getLocation(), Sound.WITHER_DEATH, 1.0F, 1.0F);
                all.sendMessage(
                  Main.pr + "§cEs werden mehr Spieler benötigt, damit das Spiel startet");
              }
            }
            if ((Countdown.lobby == 60) || (Countdown.lobby == 30) || (Countdown.lobby == 20) || (Countdown.lobby == 10) || ((Countdown.lobby <= 5) && (Countdown.lobby >= 2))) {
              for (Player all : Bukkit.getOnlinePlayers())
              {
                all.playSound(all.getLocation(), Sound.NOTE_BASS, 1.0F, 1.0F);
                all.sendMessage(Main.pr + "§7Das Spiel startet in §b" + Countdown.lobby + " §7Sekunden");
              }
            }
            if ((Countdown.lobby <= 60) && (Countdown.lobby >= 1)) {
              for (Player all : Bukkit.getOnlinePlayers()) {
                all.setLevel(Countdown.lobby);
              }
            }
          }
          if (Countdown.lobby == 1) {
            for (Player all : Bukkit.getOnlinePlayers())
            {
              all.playSound(all.getLocation(), Sound.NOTE_BASS, 1.0F, 1.0F);
              all.sendMessage(Main.pr + "§7Das Spiel startet in §b" + Countdown.lobby + " §7Sekunde");
            }
          }
          if (Countdown.lobby == 0)
          {
            for (Player all : Bukkit.getOnlinePlayers())
            {
              Main.main.utils.clearPlayer(all);
              all.sendMessage(Main.pr + "§eTeleportiere...");
              
              //Angel
              	ItemStack angel = createItem("§aAngel §8| §6Angel deine Items", Material.FISHING_ROD, 1, (short) 0);
              	angel.addUnsafeEnchantment(Enchantment.LURE, 5);
              	angel.setAmount(1);
              	ItemMeta angelm = angel.getItemMeta();
              	angel.setItemMeta(angelm);
              	all.getInventory().setItem(0, angel);
            }
            Main.main.lm.mapTeleport();
            Countdown.startFriedenCD();

            Bukkit.getScheduler().cancelTask(Countdown.lobbycd);
          }
          Countdown.lobby -= 1;
        }
      }, 0L, 20L);
    }
  }
  
  public static void startFriedenCD()
  {
    Main.main.state = Gamestate.Friede;
    friedencd = Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.main, new Runnable()
    {
      @SuppressWarnings("rawtypes")
	public void run()
      {
    	  for (Player all : Bukkit.getOnlinePlayers()) {
          Main.main.alive.contains(all);
        }
        if (Countdown.frieden >= 1)
        {
          for (Player all : Bukkit.getOnlinePlayers()) {
            if (Main.main.alive.contains(all)) {
              all.setGameMode(GameMode.SURVIVAL);
            }
          }
          if (Countdown.frieden == 1) {
            for (Player all : Bukkit.getOnlinePlayers())
            {
              all.playSound(all.getLocation(), Sound.NOTE_BASS, 1.0F, 1.0F);
              all.sendTitle("§e" + Countdown.frieden, " ");
              all.setLevel(Countdown.frieden);
 
            }
          } else if ((Countdown.frieden <= 3) && (Countdown.frieden >= 2)) {
            for (Player all : Bukkit.getOnlinePlayers())
            {
              all.playSound(all.getLocation(), Sound.NOTE_BASS, 1.0F, 1.0F);
              all.sendTitle("§e" + Countdown.frieden, " ");
              all.setLevel(Countdown.frieden);
              
            }
          }
        }
        if (Countdown.frieden == 0)
        {
          for (Player all : Bukkit.getOnlinePlayers()) {
            if (Main.main.alive.contains(all))
            {
           
              all.sendTitle("§eDas Spiel beginnt!", " ");
            }
          }
          Countdown.startIngameCD();
          Bukkit.getScheduler().cancelTask(Countdown.friedencd);
        }
        Countdown.frieden -= 1;
      }
    }, 0L, 20L);
  }
  
  public static void startIngameCD()
  {
    Main.main.state = Gamestate.Ingame;
    ingamecd = Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.main, new Runnable()
    {
      public void run()
      {
        if ((Countdown.ingame == 0) || (Main.main.alive.size() == Main.main.dmstart) || 
          (Main.main.alive.size() <= Main.main.dmstart))
        {
          Countdown.startBevorCD();
          Bukkit.getScheduler().cancelTask(Countdown.ingamecd);
        }
        Countdown.ingame -= 1;
      }
    }, 0L, 20L);
  }
  
  public static void startBevorCD()
  {
    Main.main.state = Gamestate.Ingame;
    bevorcd = Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.main, new Runnable()
    {
      public void run()
      {
        if (Countdown.bevor >= 1) {
          if ((Countdown.bevor == 60) || (Countdown.bevor == 30) || (Countdown.bevor == 10) || ((Countdown.bevor <= 5) && (Countdown.bevor >= 1))) {
            if (Countdown.bevor == 1) {
              for (Player all : Bukkit.getOnlinePlayers())
              {
                all.sendMessage(Main.pr + "§7Das Deathmatch beginnt in §b" + Countdown.bevor + " §7Sekunde");
                all.playSound(all.getLocation(), Sound.NOTE_BASS, 1.0F, 1.0F);
              }
            } else {
              for (Player all : Bukkit.getOnlinePlayers())
              {
                all.sendMessage(Main.pr + "§7Das Deathmatch beginnt in §b" + Countdown.bevor + " §7Sekunden");
                all.playSound(all.getLocation(), Sound.NOTE_BASS, 1.0F, 1.0F);
              }
            }
          }
        }
        if (Countdown.bevor == 0)
        {
          Main.main.lm.DeathmatchTeleport();
          Countdown.startDeathmatchCD();
          Bukkit.getScheduler().cancelTask(Countdown.bevorcd);
        }
        Countdown.bevor -= 1;
      }
    }, 0L, 20L);
  }
  
  public static void startDeathmatchCD()
  {
    Main.main.state = Gamestate.DeathMatch;
    deathmatchcd = Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.main, new Runnable()
    {
      public void run()
      {
        if ((Countdown.deathmatch >= 1) && (
          (Countdown.deathmatch == 30) || (Countdown.deathmatch == 20) || (Countdown.deathmatch == 10) || (
          (Countdown.deathmatch <= 5) && (Countdown.deathmatch >= 2)))) {
          for (Player all : Bukkit.getOnlinePlayers())
          {
            all.playSound(all.getLocation(), Sound.NOTE_BASS, 1.0F, 1.0F);
            all.sendMessage(Main.pr + "§7Das Spiel endet in §b" + Countdown.deathmatch + " §7Sekunden");
          }
        }
        if (Countdown.deathmatch == 0)
        {
          Countdown.startRestartCD();
          Bukkit.getScheduler().cancelTask(Countdown.deathmatchcd);
        }
        Countdown.deathmatch -= 1;
      }
    }, 0L, 20L);
  }
  
  public static void startRestartCD()
  {
    Main.main.state = Gamestate.Restarting;
    if (!restartstarted)
    {
      restartstarted = true;
      restartcd = Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.main, new Runnable()
      {
        public void run()
        {
          Iterator localIterator1;
          Iterator localIterator2;
          if (Countdown.restart >= 1)
          {
            if (Countdown.restart == 15) {
              for (localIterator1 = Bukkit.getOnlinePlayers().iterator(); localIterator1.hasNext(); localIterator2.hasNext())
              {
                Player all = (Player)localIterator1.next();
                localIterator2 = Main.main.alive.iterator(); 
                continue;
              }
            }
            if ((Countdown.restart == 15) || (Countdown.restart == 10) || ((Countdown.restart <= 5) && (Countdown.restart >= 1))) {
              if (Countdown.restart == 1) {
                for (Player all : Bukkit.getOnlinePlayers()) {
                  all.sendMessage(
                    Main.pr + "§7Der Server restartet in §b" + Countdown.restart + " §7Sekunde");
                }
              } else {
                for (Player all : Bukkit.getOnlinePlayers()) {
                  all.sendMessage(
                    Main.pr + "§7Der Server restartet in §b" + Countdown.restart + " §7Sekunden");
                }
              }
            }
          }
          else if (Countdown.restart == 0)
          {
            for (Player all : Bukkit.getOnlinePlayers()) {
              all.kickPlayer("Reload");
            
            }
            Bukkit.getScheduler().cancelTask(Countdown.restartcd);
            Bukkit.shutdown();
          }
          Countdown.restart -= 1;
        }
      }, 0L, 20L);
    }
  }


  
  private static ItemStack createItem(String name, Material type, int amount, int id)
  {
    ItemStack i1 = new ItemStack(type);
    ItemMeta i1m = i1.getItemMeta();
    i1.setAmount(amount);
    i1m.setDisplayName(name);
    i1.setItemMeta(i1m);
    return i1;
  }
}


