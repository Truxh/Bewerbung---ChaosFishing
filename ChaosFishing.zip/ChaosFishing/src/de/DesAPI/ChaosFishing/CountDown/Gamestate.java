package de.DesAPI.ChaosFishing.CountDown;

public enum Gamestate
{
  Lobby,  Ingame, DeathMatch, Friede,  Restarting;
}
